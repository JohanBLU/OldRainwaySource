<?
	include "../global.php";
?>
	<div class="lander">
		<h1>The Rainway Installer</h1>
		Get the Installer here!
		
		<br /><br />
		<form method="get" action="https://rainway.xyz/ClientDownload/Installer/Rainway_Installer.exe">
	<button type="submit" class="btn btn-outline-dark mr-md-3 mb-2 mb-md-0">Get Installer</button>	
	
	</div>

<?php include "../footer.php"; ?>