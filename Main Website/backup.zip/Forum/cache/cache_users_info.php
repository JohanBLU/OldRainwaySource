<?php

define('PUN_USERS_INFO_LOADED', 1);

$stats = array (
  'total_users' => '64',
  'last_user' => 
  array (
    'id' => '68',
    'username' => 'BLOXYNORD',
  ),
);

?>