<?php

define('PUN_BANS_LOADED', 1);

$pun_bans = array (
  0 => 
  array (
    'id' => '1',
    'username' => 'Epiculy (imposter)',
    'ip' => '2a00:23c7:3581:501:b4dd:edaf:ff53:1101',
    'email' => 'pornhub@gmail.com',
    'message' => 'fuck u',
    'expire' => '4294962000',
    'ban_creator' => '9',
  ),
  1 => 
  array (
    'id' => '2',
    'username' => 'Retard',
    'ip' => '2a00:23c7:3581:501:5823:2bb:a404:3f2d',
    'email' => 'hsdakkdkkdsdks@gmail.com',
    'message' => 'Sussy baka',
    'expire' => NULL,
    'ban_creator' => '2',
  ),
  2 => 
  array (
    'id' => '3',
    'username' => 'Seven',
    'ip' => '2a00:23c7:3581:501:b4dd:edaf:ff53:1101',
    'email' => 'sevenrblx@protonmail.com',
    'message' => 'Why drama sir',
    'expire' => NULL,
    'ban_creator' => '2',
  ),
  3 => 
  array (
    'id' => '4',
    'username' => 'DatRobotixBoi',
    'ip' => '109.65.242.120',
    'email' => 'jhafvufjkjgfjhf@yahoo.com',
    'message' => 'You requested the ban.',
    'expire' => NULL,
    'ban_creator' => '2',
  ),
);

?>