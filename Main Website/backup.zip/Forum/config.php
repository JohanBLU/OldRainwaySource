<?php

$db_type = 'mysqli_innodb';
$db_host = 'localhost';
$db_name = 'rainmfma_forum';
$db_username = 'rainmfma_forum';
$db_password = '4apM)9@H)S07.w';
$db_prefix = 'flde_';
$p_connect = false;

$cookie_name = 'pun_cookie_g6ejrmjz';
$cookie_domain = '';
$cookie_path = '/';
$cookie_secure = 0;
$cookie_seed = 'iplidrg2ftf2wfh5';

define('PUN', 1);
