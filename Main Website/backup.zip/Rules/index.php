<?
	include "../global.php";
?>
<html>
    <body>
        <div class="lander">
		      <h1>The Rainway Rules</h1>
		      <h2>Welcome, <?php echo $usr['Username']; ?>! Here are the rules you need to keep in mind while using RAINWAY!</h2>
		      <p> <b>1. </b> Respect others, so you get respected back! </p>
		      <br>
		      <p> <b>2. </b> Do not post inappropriate material in games or forum threads, be it nudity, pornography or extreme gore. </p>
		      <br>
		      <p> <b>3. </b> Do not advertise, raid or be toxic with other players. </p>
		      <br>
		      <p> <b>4. </b> We do <em>NOT</em> accept racism in any shape or form. </p>
		      <br>
		      <p> <b>5. </b> Use common sense. </p>
		      <br>
		      <h3> Not respecting any of the rules mentioned above can and will result in a ban, which may be temporary or permanent, depending on the intensity of the situation. </h3>
	    </div>
    </body>
    	
</html>


<?php include "../footer.php"; ?>