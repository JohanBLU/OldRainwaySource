$('button').click(function() {
    $(this).prop('disabled',true);
});