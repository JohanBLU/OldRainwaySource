<? include "../global.php"; ?>
<div class="lander">
	<form method="post" action="">
		<table border="0">
			<tr>
				<td><b>Title:</b></td>
				<td><input type="text" class="input-box" name="title" style="width:498px;"></td>
			</tr>
			<tr>
				<td><b>Body:</b></td>
				<td><textarea class="input-texta" name="body" rows="10" cols="65"></textarea></td>
			</tr>
			<tr>
				<td><input type="submit" name="post" class="btn" value="Create Post"></td>
			</tr>
			<font size="2"><b>Staff:</b> Make all blog posts constructive - they must have to do
				in someway with Lorias. They must follow all regular site guidelines and they must be more
				than a sentenance in length. If there is no reason to post something, don't post it.</font><br /><br>
</form>
</div>